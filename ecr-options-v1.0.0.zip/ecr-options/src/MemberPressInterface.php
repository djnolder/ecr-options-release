<?php

namespace ECROptions;

/**
 * the MemberPressInterface class has functions used specifically to interface with MemberPress
 */
class MemberPressInterface
{
    private static $instance = null;

    public $auth_count = null;

    public $member_types = [];

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    function __construct()
    {
        // get a list of types from memberpress
        $mepr_options = \MeprOptions::fetch();
        foreach ($mepr_options->custom_fields as $mop) {
            //var_dump($mop);
            if ($mop->field_key == 'mepr_member_type') {
                $options = $mop->options;
                //var_dump($options);
                foreach ($options as $op) {
                    $this->member_types[$op->option_value] = $op->option_name;
                }
            }
        }
    }

    function user_has_subscription($user_id, $sub_id)
    {
        // get user
        $user = new \MeprUser($user_id);

        $subs = $user->subscriptions();

        foreach ($subs as $sub) {
            if ($sub->product_id == $sub_id) {
                return $sub;
            }
        }
        return false;
    }

    /**
     * manually_add_subscription function
     * 
     * Add a subscription to the sub_id for user_id if one does not already exist
     * This does NOT add a transaction, so subscription will not technically be active
     *
     * @param [type] $user_id
     * @param [type] $sub_id
     * @return void
     */
    function manually_add_subscription($user_id,  $sub_id)
    {
        if ($this->user_has_subscription($user_id, $sub_id) == false) {
            // get the product model for sub_id
            $product = new \MeprProduct($sub_id);

            // create the new subscription
            $sub = new \MeprSubscription();
            $sub->user_id = $user_id; //  set the user_id
            $sub->load_product_vars($product); // set the product variables
            $sub->status = "active"; // mark it active
            $sub->gateway = ""; // blank gateway
            $sub->store(); // store it
        }
    }

    /**
     * manually_add_transaction function
     * 
     * Add a transaction to a free subscription, used to confirm users of free subscriptions
     *
     * @param [type] $user_id
     * @param [type] $sub_id
     * @return void
     */
    function manually_add_transaction($user_id,  $sub_id)
    {
        // first check if sub is active for user
        if ($sub = $this->user_has_subscription($user_id, $sub_id)) {
            $sub = new \MeprSubscription($sub->id);
            $txn = $sub->transactions();
            if (!$txn = $sub->transactions()) {
                // no transaction let's make one
                $txn = new \MeprTransaction();
                $txn->user_id = $user_id;
                $txn->product_id = $sub_id;
                $txn->status = \MeprTransaction::$complete_str;
                $txn->subscription_id = $sub->id;

                $txn->expires_at = $sub->get_expires_at();
                $txn->created_at = current_time('mysql');

                $res = $txn->store();
                if ($res) {
                    return ['status' => 'success', 'message' => 'Transaction added'];
                } else {
                    return ['status' => 'error', 'message' => 'Transaction could not be added'];
                }
            } else {
                return ['status' => 'error', 'message' => 'User already has transaction'];
            }
        } else {
            return ['status' => 'error', 'message' => 'User does not have subscription'];
        }
    }

    /**
     * make_sure_everyone_has_the_subscription function
     *
     * Check all non-admin users for subscription to sub_id and add where neccessary
     * 
     * @param [type] $sub_id
     * @return void
     */
    function make_sure_everyone_has_the_subscription($sub_id)
    {
        $users_to_update = get_users(array(
            'role__not_in' => 'administrator', // Excludes users with the 'administrator' role
            'fields'       => 'id',           // Retrieves all user data
        ));
        foreach ($users_to_update as $user_id) {

            // skip admins
            if (user_can($user_id, 'manage_options')) {
                return;
            }

            // add subscription to user NOTE: manually_add_subscription function handles if exists
            $this->manually_add_subscription($user_id, $sub_id);
        }
    }

    function get_members_without_transactions($sub_id, $limit = null, $offset = null, $is_admin = false)
    {
        global $wpdb;

        $output = [];

        $sql = "SELECT s.* FROM {$wpdb->prefix}mepr_subscriptions AS s JOIN $wpdb->users AS u ON u.ID = s.user_id LEFT JOIN {$wpdb->prefix}mepr_transactions AS t ON s.id = t.subscription_id WHERE s.product_id = {$sub_id} AND (t.status IS NULL OR t.status NOT IN ('complete', 'confirmed'))";

        if (!$is_admin) {
            $sql .= " AND (SELECT count(*) FROM {$wpdb->usermeta} AS mu WHERE mu.meta_key='wp_capabilities' AND mu.meta_value NOT LIKE '%administrator%' AND mu.user_id = s.user_id)";
        }

        if ($limit != null) $sql .= " LIMIT {$limit}";
        if ($offset != null) $sql .= " OFFSET {$offset}";
        $subs = $wpdb->get_results($sql);

        foreach ($subs as $sub) {
            if ($user = get_user_by('id', $sub->user_id)) {
                $user->meta = get_user_meta($sub->user_id);
                $user->sub_created_at = $sub->created_at;
                $output[] = $user;
            }
        }

        return $output;
    }

    function get_members_without_transactions_count($sub_id, $is_admin = false)
    {
        if (empty($this->auth_count[$sub_id])) {
            global $wpdb;

            $sql = "SELECT COUNT(*) FROM {$wpdb->prefix}mepr_subscriptions AS s JOIN $wpdb->users AS u ON u.ID = s.user_id LEFT JOIN {$wpdb->prefix}mepr_transactions AS t ON s.id = t.subscription_id WHERE s.product_id = {$sub_id} AND (t.status IS NULL OR t.status NOT IN ('complete', 'confirmed'))";

            if (!$is_admin) {
                $sql .= " AND (SELECT count(*) FROM {$wpdb->usermeta} AS mu WHERE mu.meta_key='wp_capabilities' AND mu.meta_value NOT LIKE '%administrator%' AND mu.user_id = s.user_id)";
            }


            $this->auth_count[$sub_id] = $wpdb->get_var($sql);
        }

        return  $this->auth_count[$sub_id];
    }

    function type_name($index)
    {
        // get a list of types from memberpress
        $mepr_options = \MeprOptions::fetch();
        foreach ($mepr_options as $mop) {
            if ($mop->field_key == 'mepr_member_type') {
                $options = $mop->options;
                foreach ($options as $op) {
                    if ($op->option_value == $index) {
                        return $op->option_name;
                    }
                }
            }
        }
        return false;
    }
}
