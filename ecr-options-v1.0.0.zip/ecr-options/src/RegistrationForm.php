<?php

namespace ECROptions;

class RegistrationForm
{

    function __construct()
    {
        //
        add_shortcode('ecr_signup_form', [$this, 'ecr_signup_form_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_script_for_signup_form']);
    }

    function enqueue_script_for_signup_form()
    {
        global $post;

        // only enqueue the script if the shortcode is on the page
        if (has_shortcode($post->post_content, 'ecr_signup_form')) {
            wp_enqueue_script(
                'ecr-memberpress',
                ECR_URL . '/assets/js/RegistrationForm.js',
                array('jquery'),
                time(),
                true // Load in footer
            );

            wp_localize_script('ecr-memberpress', 'wpLoginData', [
                'isLoggedIn' => is_user_logged_in(),
                'loginUrl'   => '/login',
                'logoutUrl'  => wp_logout_url(home_url()),
            ]);
        }
    }

    function ecr_signup_form_shortcode()
    {

        $data['states']  = [
            "AL" => "Alabama",
            "AK" => "Alaska",
            "AZ" => "Arizona",
            "AR" => "Arkansas",
            "CA" => "California",
            "CO" => "Colorado",
            "CT" => "Connecticut",
            "DE" => "Delaware",
            "FL" => "Florida",
            "GA" => "Georgia",
            "HI" => "Hawaii",
            "ID" => "Idaho",
            "IL" => "Illinois",
            "IN" => "Indiana",
            "IA" => "Iowa",
            "KS" => "Kansas",
            "KY" => "Kentucky",
            "LA" => "Louisiana",
            "ME" => "Maine",
            "MD" => "Maryland",
            "MA" => "Massachusetts",
            "MI" => "Michigan",
            "MN" => "Minnesota",
            "MS" => "Mississippi",
            "MO" => "Missouri",
            "MT" => "Montana",
            "NE" => "Nebraska",
            "NV" => "Nevada",
            "NH" => "New Hampshire",
            "NJ" => "New Jersey",
            "NM" => "New Mexico",
            "NY" => "New York",
            "NC" => "North Carolina",
            "ND" => "North Dakota",
            "OH" => "Ohio",
            "OK" => "Oklahoma",
            "OR" => "Oregon",
            "PA" => "Pennsylvania",
            "RI" => "Rhode Island",
            "SC" => "South Carolina",
            "SD" => "South Dakota",
            "TN" => "Tennessee",
            "TX" => "Texas",
            "UT" => "Utah",
            "VT" => "Vermont",
            "VA" => "Virginia",
            "WA" => "Washington",
            "WV" => "West Virginia",
            "WI" => "Wisconsin",
            "WY" => "Wyoming"
        ];

        ob_start();
        Main::get_template('RegistrationForm', $data);
        return ob_get_clean();
    }
}
