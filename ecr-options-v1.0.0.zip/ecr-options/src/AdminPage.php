<?php

namespace ECROptions;

class AdminPage
{

    public $tabs = [];

    function __construct()
    {

        add_action('admin_menu', [$this, 'ecr_utilties_page']);
    }

    function ecr_utilties_page()
    {
        add_menu_page(
            'ECR Utilities',
            'ECR Utilities',
            'manage_options',
            'ect-utilities',
            [$this, 'ecr_utilties_page_content'],
            plugins_url('ecr-options/img/icon.png'),
            2
        );
    }

    function ecr_utilties_page_content()
    {
        $mpi = MemberPressInterface::getInstance();
        $auth_count = $mpi->get_members_without_transactions_count(3307);

        $this->tabs = [
            "" => [
                'name' => "Main",
                'class' => 'AdminPageTabMain'
            ],
            "authorizations" => [
                'name' => "Authorizations ({$auth_count})",
                'class' => 'AdminPageTabAuthorizations'
            ],
            "salesforce" => [
                'name' => "Salesforce",
                'class' => 'AdminPageTabSalesforce'
            ],
            /*"csv" => [
                'name' => "CSV Import",
                'class' => 'AdminPageTabMain'
            ],*/
        ];

        $_GET['tab'] = $_GET['tab'] ?? '';

        $class_name = '\ECROptions\\' . $this->tabs[$_GET['tab']]['class'];

        $tab_class = new $class_name();

        $data['tabs'] = $this->tabs;
        ob_start();
        $tab_class->render();
        $data['class_render'] = ob_get_clean();

        Main::get_template('AdminPage', $data);
    }

    function get_user_fields()
    {

        $u = new \MeprUser();
        $meprfields = $u->custom_profile_fields(true);
        $fields = [
            'email' => 'Email',
            'display_name' => 'Display Name',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'nickname' => 'Nickname',
        ];

        foreach ($meprfields as $meprfield) {
            $fields[$meprfield->field_key] = $meprfield->field_name;
        }

        return $fields;
    }
}
