<?php

namespace ECROptions;

class AdminPageTabAuthorizations
{

    function __construct() {}

    function render()
    {
        echo "<p style=\"font-size: 30px;\">NOTE: The Deny buttons do not currently work</p>";
        echo '<form method="post">';
        $myListTable = new AdminPageListTable();
        $myListTable->prepare_items();
        $myListTable->display();
        echo '</form>';
    }
}
