<?php

namespace ECROptions;

class FileUpload
{

    function __construct()
    {
        add_action('wp_ajax_my_file_upload', [$this, 'handle_my_file_upload']);
        add_action('wp_ajax_nopriv_my_file_upload', [$this, 'handle_my_file_upload']);
    }

    function handle_my_file_upload()
    {
        if (! check_ajax_referer('ecr-file-upload-nonce', 'nonce', false)) {
            wp_send_json_error('Security failed.');
            wp_die();
        }

        if (isset($_FILES['file'])) {
            $upload_dir = wp_upload_dir();
            $custom_dir = $upload_dir['basedir'] . "/ecr-uploads/";

            if (!file_exists($custom_dir)) {
                wp_mkdir_p($custom_dir);
            }

            $uploaded_file = $_FILES['file'];
            // if parse is set, we don't save the file, we parse the data and return it
            if (isset($_POST['parse'])) {
                $parse_function = 'parse_' . $_POST['parse'];
                if (method_exists($this, $parse_function)) {
                    $data = call_user_func([$this, $parse_function], $uploaded_file);
                    wp_send_json($data);
                    wp_die();
                }
            }


            $file_name = sanitize_file_name($uploaded_file['name']);
            $destination_path = $custom_dir . $file_name;

            if (move_uploaded_file($uploaded_file['tmp_name'], $destination_path)) {
                wp_send_json_success($destination_path);
            } else {
                wp_send_json_error('Failed to upload file.');
            }
        } else {
            wp_send_json_error('You forgot the file to upload.');
        }

        wp_die();
    }

    function parse_csv($file)
    {
        $data = [];
        if (($handle = fopen($file['tmp_name'], 'r')) !== FALSE) {
            while (($row = fgetcsv($handle, 1000, ',')) !== FALSE) {
                if (isset($keys)) {
                    $data[] = array_combine($keys, $row);
                } else {
                    $keys = $row;
                }
            }
            fclose($handle);
        } else {
            return ['success' => false, 'message' => 'This is not a valid CSV file.'];
        }
        return ['success' => true, 'data' => $data];
    }
}
