;(function ($) {
  //

  $(document).on("click", ".approve_member", function (e) {
    e.preventDefault()
    e.stopPropagation()
    const parent = $(this).parent()
    parent.children().hide()
    parent.find(".action_wait").show()

    var member_id = $(this).data("member_id")

    var formData = new FormData()
    formData.append("nonce", nonce)
    formData.append("action", "ecr_options")
    formData.append("method", "approve_member")
    formData.append("member_id", member_id)

    $.ajax({
      url: ajaxurl,
      type: "post",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        res = JSON.parse(response)
        if (res.status == "success") {
          parent
            .find(".status")
            .html("Contact has been approved!<br/>Closing modal...")
            .addClass("approved")
            .css("display", "flex")

          $(".nav-tab[data-tab='authorizations']").click()

          setTimeout(() => {
            tb_remove()
          }, 2000)
        } else {
          alert("Error: " + res.message)
        }
        console.log(res)
        parent.find(".action_wait").hide()
      },
      error: function (xhr, status, error) {
        console.log(xhr.responseText)
      },
    })
  })

  $(document).on("click", ".deny_member", function (e) {
    e.preventDefault()
    e.stopPropagation()
    const parent = $(this).parent()
    parent.children().hide()
    parent.find(".action_wait").show()

    setTimeout(() => {
      var member_id = $(this).data("member_id")
      console.log(member_id)
      parent.find(".action_wait").hide()
      parent.find(".button").show()
    }, 1000)
  })

  $(document).on("click", ".nav-tab-wrapper a", function (e) {
    e.preventDefault()
    e.stopPropagation()

    $("#tab-inner").html(
      "<div class='nav_wait_wrapper'><div class='nav_wait'><img src='/wp-includes/js/thickbox/loadingAnimation.gif' /></div></div>"
    )

    q = new URLSearchParams($(this).attr("href"))

    // switch active css
    $(this).siblings().removeClass("nav-tab-active")
    $(this).addClass("nav-tab-active").blur()

    const tab_class = $(this).data("tab_class")
    const tab = $(this).data("tab")

    // swtich the URL
    const url = new URL(location)
    if (q.get("tab")) {
      url.searchParams.set("tab", q.get("tab"))
    } else {
      url.searchParams.delete("tab")
    }
    history.pushState({}, "", url)

    var formData = new FormData()
    formData.append("nonce", nonce)
    formData.append("action", "ecr_options")
    formData.append("method", "get_tab_content")
    formData.append("tab", tab)
    formData.append("tab-class", tab_class)

    $.ajax({
      url: ajaxurl,
      type: "post",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        $("#tab-inner").html(response)
      },
      error: function (xhr, status, error) {
        $("#dragandrophandlerstatus").css("color", "#FF4444")
        $("#dragandrophandlerstatus").css("border-color", "#FF4444")
        $("#dragandrophandlerstatus").text("ERROR: xhr.responseText")
      },
    })
  })

  $(document).on("click", ".auths tr", function (e) {
    e.preventDefault()
    e.stopPropagation()

    const member_id = $(this).data("member_id")
    console.log(
      "#TB_inline?1=1&width=600&height=400&inlineId=more_details_" + member_id
    )
    tb_show(
      "Modal Title",
      "#TB_inline?1=1&width=600&height=400&inlineId=more_details_" + member_id
    )
  })
})(jQuery)
