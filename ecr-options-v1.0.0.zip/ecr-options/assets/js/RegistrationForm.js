class RegistrationForm {
  constructor(formId, responseId, apiEndpoint) {
    this.form = document.getElementById(formId)
    this.responseBox = document.getElementById(responseId)
    this.formError = document.getElementById("form-error-message")
    this.passwordInput = document.getElementById("user_pass")
    this.showPasswordButtons = document.querySelectorAll(".show-password")
    this.apiEndpoint = apiEndpoint
    this.steps = [...this.form.querySelectorAll(".form-step")]
    this.currentStep = 0
    this.submitBtn = document.getElementById("submit-registration")
    this.init()
  }

  init() {
    this.applyInputMasking()
    this.showStep(0)
    this.setupNavigation()
    this.setupDynamicLocations()
    this.form.addEventListener("submit", (e) => this.handleSubmit(e))

    if (this.passwordInput) {
      this.passwordInput.addEventListener("input", () => {
        const val = this.passwordInput.value

        document
          .getElementById("tip-length")
          .classList.toggle("valid", val.length >= 12)
        document
          .getElementById("tip-uppercase")
          .classList.toggle("valid", /[A-Z]/.test(val))
        document
          .getElementById("tip-number")
          .classList.toggle("valid", /[0-9]/.test(val))
        document
          .getElementById("tip-special")
          .classList.toggle("valid", /[^A-Za-z0-9]/.test(val))
      })
    }

    if (this.showPasswordButtons) {
      this.showPasswordButtons.forEach((button) => {
        button.addEventListener("click", () => {
          const input = button.previousElementSibling
          if (input) {
            const isHidden = input.type === "password"
            input.type = isHidden ? "text" : "password"
            button.textContent = isHidden ? "Hide password" : "Show password"
          }
        })
      })
    }
  }

  setupNavigation() {
    this.form
      .querySelectorAll(".next-step")
      .forEach((btn) => btn.addEventListener("click", () => this.nextStep()))
    this.form
      .querySelectorAll(".prev-step")
      .forEach((btn) => btn.addEventListener("click", () => this.prevStep()))
  }

  setupDynamicLocations() {
    const field = this.form.querySelector('[name="additional_locations"]')
    if (!field) return
    field.addEventListener("input", () => this.updateAdditionalLocations())
  }

  applyInputMasking() {
    const phoneFields = this.form.querySelectorAll('[name*="phone"]')
    phoneFields.forEach((f) =>
      f.addEventListener("input", () => this.maskPhone(f))
    )

    const zipFields = this.form.querySelectorAll('[name*="zip"]')
    zipFields.forEach((f) => f.addEventListener("input", () => this.maskZip(f)))

    const emailField = this.form.querySelector('[name="user_email"]')
    if (emailField) {
      emailField.addEventListener("input", () => {
        emailField.value = emailField.value.replace(/\s/g, "")
      })
    }
  }

  showStep(index) {
    this.steps.forEach((step, i) => {
      step.classList.toggle("active", i === index)
    })
    this.currentStep = index
  }

  nextStep() {
    if (this.validateStep(this.currentStep)) {
      this.showStep(this.currentStep + 1)
    }
  }

  prevStep() {
    this.showStep(this.currentStep - 1)
  }

  validateStep(index) {
    let valid = true
    const inputs = this.steps[index].querySelectorAll("[required]")
    inputs.forEach((input) => {
      const msg = input.closest("label")?.querySelector(".error-msg")
      if (msg) msg.textContent = ""

      const value = input.value.trim()

      if (!value) {
        if (msg) msg.textContent = "This field is required"
        valid = false
      } else if (
        input.type === "email" &&
        !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value)
      ) {
        if (msg) msg.textContent = "Invalid email"
        valid = false
      } else if (
        input.name.includes("phone") &&
        !/^\d{3}-\d{3}-\d{4}$/.test(value)
      ) {
        if (msg) msg.textContent = "Format: 123-456-7890"
        valid = false
      } else if (input.name.includes("zip") && !/^\d{5}$/.test(value)) {
        if (msg) msg.textContent = "ZIP must be 5 digits"
        valid = false
      }
    })

    // Password validation (if password field exists on this step)
    const password = this.steps[index].querySelector("#user_pass")
    const confirm = this.steps[index].querySelector("#user_pass_confirm")

    if (password && confirm) {
      const passVal = password.value.trim()
      const confirmVal = confirm.value.trim()
      const passMsg = password.closest("label")?.querySelector(".error-msg")
      const confirmMsg = confirm.closest("label")?.querySelector(".error-msg")
      if (passMsg) passMsg.textContent = ""
      if (confirmMsg) confirmMsg.textContent = ""

      const passErrors = []
      if (passVal.length < 12) passErrors.push("At least 12 characters")
      if (!/[A-Z]/.test(passVal)) passErrors.push("1 uppercase letter")
      if (!/[0-9]/.test(passVal)) passErrors.push("1 number")
      if (!/[^A-Za-z0-9]/.test(passVal)) passErrors.push("1 special character")

      if (passErrors.length > 0) {
        if (passMsg) passMsg.textContent = passErrors.join(", ")
        valid = false
      }

      if (passVal !== confirmVal) {
        if (confirmMsg) confirmMsg.textContent = "Passwords do not match"
        valid = false
      }
    }

    return valid
  }

  maskPhone(input) {
    let val = input.value.replace(/\D/g, "").slice(0, 10)
    const parts = []
    if (val.length > 0) parts.push(val.slice(0, 3))
    if (val.length > 3) parts.push(val.slice(3, 6))
    if (val.length > 6) parts.push(val.slice(6))
    input.value = parts.join("-")
  }

  maskZip(input) {
    input.value = input.value.replace(/\D/g, "").slice(0, 5)
  }

  updateAdditionalLocations() {
    const count = parseInt(
      this.form.querySelector('[name="additional_locations"]').value
    )
    const container = document.getElementById("additional-locations-container")
    const message = document.getElementById("too-many-locations-message")
    const stateOptions = this.form.querySelector(
      '[name="mepr-address-state"]'
    ).innerHTML

    container.innerHTML = ""
    message.style.display = count > 2 ? "block" : "none"
    if (count > 2) return

    for (let i = 1; i <= count; i++) {
      const section = document.createElement("div")
      section.innerHTML = `
        <h4>Additional Location ${i}</h4>
        <div class="form-group-2">
        <label>Address Line 1: <input type="text" name="mepr_location_${i}_address_1" required><span class="error-msg"></span></label>
        <label>Address Line 2: <input type="text" name="mepr_location_${i}_address_2"></label>
        </div>
        <div class="form-group-3">
        <label>City: <input type="text" name="mepr_location_${i}_city" required><span class="error-msg"></span></label>
        <label>State:
          <select name="mepr_location_${i}_state" required>${stateOptions}</select><span class="error-msg"></span>
        </label>
        <label>ZIP Code: <input type="text" name="mepr_location_${i}_zip" required><span class="error-msg"></span></label>
        </div>
      `
      container.appendChild(section)

      section
        .querySelector(`[name="mepr_location_${i}_zip"]`)
        .addEventListener("input", (e) => this.maskZip(e.target))
    }
  }

  validatePasswordFields() {
    const password = document.getElementById("user_pass").value.trim()
    const confirm = document.getElementById("user_pass_confirm").value.trim()
    const passError = document.getElementById("pass-error")
    const confirmError = document.getElementById("confirm-error")

    // Clear old messages
    passError.textContent = ""
    confirmError.textContent = ""

    const errors = []

    if (password.length < 12) {
      errors.push("At least 12 characters")
    }
    if (!/[A-Z]/.test(password)) {
      errors.push("At least one uppercase letter")
    }
    if (!/[0-9]/.test(password)) {
      errors.push("At least one number")
    }
    if (!/[^A-Za-z0-9]/.test(password)) {
      errors.push("At least one special character")
    }

    if (errors.length > 0) {
      passError.textContent = errors.join(", ")
      return false
    }

    if (password !== confirm) {
      confirmError.textContent = "Passwords do not match"
      return false
    }

    return true
  }

  async handleSubmit(e) {
    e.preventDefault()

    if (!this.validateStep(this.currentStep)) return

    const formData = new FormData(this.form)

    const address = {
      "mepr-address-one": formData.get("mepr-address-one"),
      "mepr-address-two": formData.get("mepr-address-two"),
      "mepr-address-city": formData.get("mepr-address-city"),
      "mepr-address-state": formData.get("mepr-address-state"),
      "mepr-address-zip": formData.get("mepr-address-zip"),
      "mepr-address-country": "United States",
    }

    const meta = {
      mepr_practice_name: formData.get("mepr_practice_name"),
      mepr_practice_phone: formData.get("mepr_practice_phone"),
      mepr_website: formData.get("mepr_website"),
      mepr_member_type: formData.get("mepr_member_type"),
      mepr_referred_by: formData.get("mepr_referred_by"),
      mepr_referring_rep_name: formData.get("mepr_referring_rep_name"),
      additional_locations: formData.get("additional_locations") || "0",
    }

    const locationCount = parseInt(meta["additional_locations"])
    if (locationCount > 0 && locationCount <= 2) {
      for (let i = 1; i <= locationCount; i++) {
        ;["address_1", "address_2", "city", "state", "zip"].forEach((key) => {
          const fieldName = `mepr_location_${i}_${key}`
          meta[fieldName] = formData.get(fieldName) || ""
        })
      }
    }

    const data = {
      email: formData.get("user_email"),
      password: formData.get("user_pass_confirm"),
      first_name: formData.get("first_name"),
      last_name: formData.get("last_name"),
      address: address,
      meta: meta,
    }

    try {
      document.querySelector(".form-step.active").style.opacity = "0.1"
      this.responseBox.style.display = "block"
      this.responseBox.style.color = "black"
      this.responseBox.innerHTML = `
<div class="spinner" style="
      width: 24px;
      height: 24px;
      border: 4px solid rgba(0, 0, 0, 0.1);
      border-top-color: #000;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto;
    "></div>
    <p style="text-align:center; margin-top: 10px;">Processing registration...</p>`
      this.submitBtn.disabled = true
      this.passwordInput.type = "password"

      const res = await fetch("/wp-json/custom/v1/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      const result = await res.json()
      console.log(result)
      if (res.ok) {
        this.form.reset()
        document.getElementById("additional-locations-container").innerHTML = ""
        // Redirect a user to the thank you page on signup.
        window.location.replace("/join-today/thank-you/")
      } else {
        document.querySelector(".form-step.active").style.opacity = "1"

        this.responseBox.style.display = "none"
        this.responseBox.innerHTML = ""

        this.formError.style.color = "red"
        this.formError.textContent = `Registration not successful. Please review your application and try again.`
      }
    } catch (err) {
      this.formError.style.color = "red"
      this.formError.textContent = "Error: " + err.message
    }
  }
}

function handleHeaderButtonSwap() {
  if (typeof wpLoginData === "undefined") return

  const loginBtn = document.querySelector(".header-login-button")
  if (!loginBtn) return

  const loginText = loginBtn.querySelector(".elementor-button-text") || loginBtn
  const loginHref = loginBtn.querySelector("a.elementor-button-link")

  const headerJoinLink = document.querySelector(
    ".elementor-nav-menu--main li.page-3060"
  )

  loginText.textContent = wpLoginData.isLoggedIn ? "Log Out" : "Log In"
  loginHref.href = wpLoginData.isLoggedIn
    ? wpLoginData.logoutUrl
    : wpLoginData.loginUrl

  if (wpLoginData.isLoggedIn) {
    headerJoinLink.style.display = "none"
    headerJoinLink.style.visibility = "hidden"
  }

  loginBtn.style.visibility = "visible"
}

// Initialize on DOM ready
document.addEventListener("DOMContentLoaded", () => {
  new RegistrationForm(
    "custom-signup-form",
    "form-response",
    "/wp-json/custom/v1/register"
  )
  handleHeaderButtonSwap()
})
