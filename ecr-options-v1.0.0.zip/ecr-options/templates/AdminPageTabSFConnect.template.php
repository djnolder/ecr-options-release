<div class="postbox-container">
    <div class="postbox postbox-70">
        <div class="postbox-header">
            <h2>Salesforce Connect</h2>
        </div>
        <div class="inside">
            <?php if (isset($contacts_error)) : ?>
                <h3><?= $contacts_error ?></h3>
            <?php else: ?>
                <table border=1>
                    <tr>
                        <th colspan='5'><?= $contacts_count ?> total contacts on SF!</th>
                    </tr>
                    <tr>
                        <th colspan='5'><?= count($sf_only) ?> are in Salesforce ONLY!</th>
                    </tr>
                    <?php foreach ($sf_only as $record) : ?>
                        <tr>
                            <td><?= $record['Name'] ?></td>
                            <td><?= $record['Email'] ?></td>
                            <td><?= $record['Phone'] ?></td>
                            <td><?= $record['Account']['Name'] ?></td>
                            <td><?= $record['Member_Type__c'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <th colspan='5'><?= $users_count ?> total accounts on MP!</th>
                    </tr>
                    <tr>
                        <th colspan='5'><?= count($mp_only) ?> are in MemberPress ONLY!</th>
                    </tr>
                    <?php foreach ($mp_only as $u) : ?>
                        <tr>
                            <td><?= $u->display_name ?></td>
                            <td><?= $u->user_email ?></td>
                            <td><?= $u->metadata['mepr_practice_phone'][0] ?? '' ?></td>
                            <td><?= $u->metadata['mepr_practice_name'][0] ?? '' ?></td>
                            <td><?= $u->metadata['mepr_member_type'][0] ?? '' ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <div class="postbox postbox-connect">
        <div class="postbox-header">
            <h2>Salesforce Connect</h2>
        </div>
        <div class="inside">
            <a href="<?= $disconnect_link ?>" target="_blank" onClick="window.open(this.href, 'Salesforce Connect' , 'width=800,height=600,menubar=yes,toolbar=yes,location=yes,status=yes' ); return false;" class="button">CONNECT TO SALESFORCE!</a>
            <a href="<?= $connect_link ?>" target="_blank" onClick="window.open(this.href, 'Salesforce Connect' , 'width=800,height=600,menubar=yes,toolbar=yes,location=yes,status=yes' ); return false;" class="button red">DISCONNECT FROM SALESFORCE!</a>
            <div id="sf_status"></div>
        </div>
    </div>
</div>
<style>
    .postbox-container {
        display: flex;
        flex-wrap: wrap;
        width: 100%;
        align-items: flex-start;
        gap: 20px;
    }

    .postbox-container h2 {
        font-size: 14px;
        padding: 8px 12px;
        margin: 0;
        line-height: 1.4
    }

    .postbox {
        padding: 10px;
    }

    .postbox-connect {
        width: 240px;
    }

    .postbox-connect .inside {
        display: flex;
        flex-direction: column;
        gap: 10px;
        justify-content: center;
        align-items: center;
    }

    .postbox-connect .inside .button {
        margin: 5px;
    }

    .postbox-70 {
        flex-grow: 1;
    }
</style>
<script>
    function update_sf_status(message) {
        jQuery('#sf_status').text(message);
    }
</script>