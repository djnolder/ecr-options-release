<form id="custom-signup-form">
    <!-- STEP 1 -->
    <div class="form-step active">
        <h2>Name &amp; Practice Information</h2>
        <div class="form-grid-2">
            <label>First Name: <input type="text" name="first_name" required><span class="error-msg"></span></label>
            <label>Last Name: <input type="text" name="last_name" required><span class="error-msg"></span></label>
        </div>
        <div class="form-grid-2">
            <label>Practice Name: <input type="text" name="mepr_practice_name" required><span class="error-msg"></span></label>
            <label>Practice Phone: <input type="tel" name="mepr_practice_phone" required><span class="error-msg"></span></label>
        </div>
        <button type="button" class="next-step">Next</button>
    </div>

    <!-- STEP 2 -->
    <div class="form-step">
        <h2>Practice Location(s)</h2>
        <p>We are currently only accepting U.S. based practices at this time.</p>
        <div class="form-grid-2">
            <label>Address 1: <input type="text" name="mepr-address-one" required><span class="error-msg"></span></label>
            <label>Address 2: <input type="text" name="mepr-address-two"></label>
        </div>
        <div class="form-grid-3">
            <label>City: <input type="text" name="mepr-address-city" required><span class="error-msg"></span></label>
            <label>
                State:
                <select name="mepr-address-state" required>
                    <option value="">Select State</option>
                    <?php foreach ($states as $abbr => $name) : ?>
                        <option value="<?= $abbr ?>"><?= $name ?></option>
                    <? endforeach; ?>
                </select>
                <span class="error-msg"></span>
            </label>
            <label>ZIP Code: <input type="text" name="mepr-address-zip" required><span class="error-msg"></span></label>
        </div>
        <label>Website: <input type="text" name="mepr_website"><span class="error-msg"></span></label>
        <label>
            How many additional locations does your practice have?
            <input type="number" name="additional_locations" id="additional_locations" min="0" required>
            <span class="error-msg"></span>
        </label>

        <div id="additional-locations-container"></div>

        <div id="too-many-locations-message" style="display: none; color: red;">
            If you have more than three locations, please continue to fill out the form and register as a member of Eyecare Republic. A member of our team will reach out to you for more information.
        </div>
        <div class="form-grid-2">
            <button type="button" class="prev-step">Back</button>
            <button type="button" class="next-step">Next</button>
        </div>
    </div>

    <!-- STEP 3 -->
    <div class="form-step">
        <h2>Additional Info</h2>
        <label>Member Type:
            <select name="mepr_member_type" required>
                <option value="">Select</option>
                <option value="optometrist">Optometrist</option>
                <option value="ophthalmologist">Ophthalmologist</option>
                <option value="non-od-owner">Non OD Owner</option>
                <option value="student">Student</option>
                <option value="other">Other</option>
            </select>
            <span class="error-msg"></span>
        </label>
        <div class="form-grid-2">
            <label>Referred By:
                <select name="mepr_referred_by" required>
                    <option value="">Select</option>
                    <option value="eyecare-republic-rep">Eyecare Republic Rep</option>
                    <option value="bl-rep">B+L Rep</option>
                    <option value="other-ecp">Other ECP</option>
                    <option value="other-vendor-rep">Other Vendor Rep</option>
                    <option value="other">Other</option>
                    <option value="no-referral">No Referral</option>
                </select>
                <span class="error-msg"></span>
            </label>
            <label>Referring Rep Name: <input type="text" name="mepr_referring_rep_name"></label>
        </div>
        <span>If you were referred by someone not in the dropdown, please specify. <br />If you were not referred by anyone, please enter N/A. </span>
        <div class="form-grid-2">
            <button type="button" class="prev-step">Back</button>
            <button type="button" class="next-step">Next</button>
        </div>
    </div>

    <!-- STEP 4 -->
    <div class="form-step active">
        <label>Email: <input type="email" name="user_email" required><span class="error-msg"></span></label>
        <label>
            Password:
            <input type="password" id="user_pass" name="user_pass" required>
            <button type="button" class="show-password">Show password</button>
            <span class="error-msg" id="pass-error"></span>
        </label>

        <label>
            Confirm Password:
            <input type="password" id="user_pass_confirm" name="user_pass_confirm" required>
            <button type="button" class="show-password">Show password</button>
            <span class="error-msg" id="confirm-error"></span>
        </label>
        <p>Password must contain:</p>
        <ul id="password-tips" style="list-style: none; padding-left: 0; font-size: 0.9em;">
            <li id="tip-length" class="tip">At least 12 characters</li>
            <li id="tip-uppercase" class="tip">At least one uppercase letter</li>
            <li id="tip-number" class="tip">At least one number</li>
            <li id="tip-special" class="tip">At least one special character</li>
        </ul>
        <button type="submit" id="submit-registration">Submit</button>
        <button type="button" class="prev-step">Back</button>
    </div>

    <div id="form-response" style="margin-top: 1em;"></div>
    <div id="form-error-message" style="margin-top: 1em;"></div>
</form>