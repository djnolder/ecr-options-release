<?php

namespace ECROptions;

class RegistrationForm
{

    function __construct()
    {
        //
        add_shortcode('ecr_signup_form', [$this, 'ecr_signup_form_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_script_for_signup_form']);

        add_action('rest_api_init', function () {
            register_rest_route('custom/v1', '/register', [
                'methods' => 'POST',
                'callback' => [$this, 'register_user'],
                'permission_callback' => '__return_true',
            ]);
        });
    }

    function enqueue_script_for_signup_form()
    {
        global $post;

        // only enqueue the script if the shortcode is on the page
        if (has_shortcode($post->post_content, 'ecr_signup_form')) {
            wp_enqueue_script(
                'ecr-memberpress',
                ECR_URL . '/assets/js/RegistrationForm.js',
                array('jquery'),
                time(),
                true // Load in footer
            );

            wp_localize_script('ecr-memberpress', 'wpLoginData', [
                'isLoggedIn' => is_user_logged_in(),
                'loginUrl'   => '/login',
                'logoutUrl'  => wp_logout_url(home_url()),
            ]);
        }
    }

    function ecr_signup_form_shortcode()
    {

        $data['states']  = [
            "AL" => "Alabama",
            "AK" => "Alaska",
            "AZ" => "Arizona",
            "AR" => "Arkansas",
            "CA" => "California",
            "CO" => "Colorado",
            "CT" => "Connecticut",
            "DE" => "Delaware",
            "FL" => "Florida",
            "GA" => "Georgia",
            "HI" => "Hawaii",
            "ID" => "Idaho",
            "IL" => "Illinois",
            "IN" => "Indiana",
            "IA" => "Iowa",
            "KS" => "Kansas",
            "KY" => "Kentucky",
            "LA" => "Louisiana",
            "ME" => "Maine",
            "MD" => "Maryland",
            "MA" => "Massachusetts",
            "MI" => "Michigan",
            "MN" => "Minnesota",
            "MS" => "Mississippi",
            "MO" => "Missouri",
            "MT" => "Montana",
            "NE" => "Nebraska",
            "NV" => "Nevada",
            "NH" => "New Hampshire",
            "NJ" => "New Jersey",
            "NM" => "New Mexico",
            "NY" => "New York",
            "NC" => "North Carolina",
            "ND" => "North Dakota",
            "OH" => "Ohio",
            "OK" => "Oklahoma",
            "OR" => "Oregon",
            "PA" => "Pennsylvania",
            "RI" => "Rhode Island",
            "SC" => "South Carolina",
            "SD" => "South Dakota",
            "TN" => "Tennessee",
            "TX" => "Texas",
            "UT" => "Utah",
            "VT" => "Vermont",
            "VA" => "Virginia",
            "WA" => "Washington",
            "WV" => "West Virginia",
            "WI" => "Wisconsin",
            "WY" => "Wyoming"
        ];

        ob_start();
        Main::get_template('RegistrationForm', $data);
        return ob_get_clean();
    }

    function register_user($request)
    {
        $params        = $request->get_json_params();
        $sub_id = 3307;

        $meta     = $params['meta'] ?? [];
        $address  = $params['address'] ?? [];

        $u = new \MeprUser();
        $u->load_from_array($params);

        $u->user_email = sanitize_email($params['email']);
        $u->user_login = $u->user_email;

        $u->set_password($params['password']);

        $user_id = $u->store();

        // Save user meta
        foreach ($meta as $key => $value) {
            update_user_meta($user_id, $key, sanitize_text_field($value));
        }
        foreach ($address as $key => $value) {
            update_user_meta($user_id, $key, sanitize_text_field($value));
        }

        // we need to add user to the main subscription
        $mpi = MemberPressInterface::getInstance();
        $mpi->manually_add_subscription($user_id, $sub_id);

        // Build address string
        $user_address = implode(', ', array_map('sanitize_text_field', $address));

        $this->send_admin_notification_email($user_id, $params['first_name'], $params['last_name'], $params['email'], $meta, $user_address);
        $this->send_user_welcome_email($params['first_name'], $params['email'], $meta);
    }

    function send_admin_notification_email($user_id, $user_first_name, $user_last_name, $user_email, $meta, $user_address)
    {
        $practice_name        = $meta['mepr_practice_name'] ?? '';
        $member_type          = $meta['mepr_member_type'] ?? '';
        $phone                = $meta['mepr_practice_phone'] ?? '';
        $website              = $meta['mepr_website'] ?? '';
        $referred_by          = $meta['mepr_referred_by'] ?? '';
        $referring_rep_name   = $meta['mepr_referring_rep_name'] ?? '';

        $admin_to   = 'rshallin@eyecarerepublic.com'; // Primary admin
        $cc_emails  = ['info@eyecarerepublic.com', 'jdody@eyecarerepublic.com'];

        /*
          -------------------------------------------------------------
          TEMPORARY! DO NOT GO LIVE!!!!
          -------------------------------------------------------------
         */
        $admin_to   = 'dejernet51@gmail.com'; // Primary admin
        $cc_emails = [];

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'Cc: ' . implode(', ', $cc_emails),
        ];

        $subject = 'New Signup Notification - Eyecare Republic';

        $mpi = MemberPressInterface::getInstance();
        $data = [
            'user_id' => $user_id,
            'user_first_name' => $user_first_name,
            'user_last_name' => $user_last_name,
            'user_email' => $user_email,
            'practice_name' => $practice_name,
            'member_type_name' => $mpi->type_name($member_type),
            'phone' => $phone,
            'website' => $website,
            'referred_by' => $referred_by,
            'referring_rep_name' => $referring_rep_name,
            'user_address' => $user_address,
        ];
        ob_start();
        Main::get_template('AdminNotificationEmail', $data);
        $message = ob_get_clean();

        wp_mail($admin_to, $subject, $message, $headers);
    }

    /* Send the new member a confirmation email */
    function send_user_welcome_email($user_first_name, $user_email, $meta)
    {
        $member_type = $meta['mepr_member_type'] ?? '';

        if ('optometrist' === $member_type || 'opthamologist' === $member_type) {
            $user_first_name = 'Dr. ' . $user_first_name;
        }

        $subject = 'Welcome to Eyecare Republic';
        $headers = ['Content-Type: text/html; charset=UTF-8'];

        $data = [
            'user_first_name' => $user_first_name,
            'user_email' => $user_email,
        ];
        ob_start();
        Main::get_template('UserWelcomeEmail', $data);
        $message = ob_get_clean();

        wp_mail($user_email, $subject, $message, $headers);
    }
}
