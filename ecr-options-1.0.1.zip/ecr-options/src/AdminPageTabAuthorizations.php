<?php

namespace ECROptions;

class AdminPageTabAuthorizations
{

    function __construct() {}

    function render()
    {
        // the list table builds pagination based off request_uri, so when we come in via ajax, we need to spoof it
        if ($_SERVER['REQUEST_URI'] == "/wp-admin/admin-ajax.php") {
            $_SERVER['REQUEST_URI'] = "/wp-admin/admin.php?page=ect-utilities&tab=authorizations";
        }
        echo "<p style=\"font-size: 30px;\">NOTE: The Deny buttons do not currently work</p>";
        echo '<form method="post">';
        $myListTable = new AdminPageListTable();
        $myListTable->prepare_items();
        $myListTable->display();
        echo '</form>';
    }
}
