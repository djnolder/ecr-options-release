<?php

namespace ECROptions;

if (! class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

use WP_List_Table;

class AdminPageListTable extends WP_List_Table
{

    function __construct()
    {
        parent::__construct([
            'singular' => 'auth',
            'plural'   => 'auths',
            'ajax'     => false
        ]);
    }

    public function single_row($item)
    {
        echo '<tr data-member_id="' . $item['id'] . '">';
        $this->single_row_columns($item);
        echo '</tr>';
    }

    function get_columns()
    {
        $columns = array(
            //'cb'                 => '<input type="checkbox" />', // I don't think we need bulk actions
            'id'                 => 'ID',
            'name'               => 'Name',
            'type'               => 'Member Type',
            'practice_name'      => 'Practice Name',
            'referred_by'        => 'Referred By',
            'referring_rep_name' => 'Referral Name',
            'created_at'         => 'Created At',
            //'actions'            => 'Actions'
        );
        return $columns;
    }

    function column_default($item, $column_name)
    {
        return $data = $item[$column_name] ?? '';
    }

    function prepare_items()
    {
        add_thickbox();

        $per_page = 10;

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array($columns, $hidden, $sortable);

        $mpi = MemberPressInterface::getInstance();
        $current_page = $this->get_pagenum();
        $total_items = $mpi->get_members_without_transactions_count(3307, true);
        $members = $mpi->get_members_without_transactions(3307, $per_page, (($current_page - 1) * $per_page));

        $this->set_pagination_args(array(
            'total_items' => $total_items, // total number of items
            'per_page'    => $per_page, // items to show on a page
            'total_pages' => ceil($total_items / $per_page), // use ceil to round up
            'add_args'    => ['page' => 'ect-utilities', 'tab' => 'authorizations']
        ));
        foreach ($members as $member) {
            $mpi = MemberPressInterface::getInstance();
            $type = $mpi->member_types[$member->meta['mepr_member_type'][0]] ?? $member->meta['mepr_member_type'][0];

            $data[] = [
                'id' => $member->id,
                'name' => $this->build_name_with_modal($member),
                'type' => $type, ///// NEED TO LOOK UP NAME, THIS IS VALUE!!!!!!!!!!!!!
                'practice_name' => $member->meta['mepr_practice_name'][0],
                'referred_by' => $member->meta['mepr_referred_by'][0],
                'referring_rep_name' => $member->meta['mepr_referring_rep_name'][0],
                'created_at' => $member->sub_created_at,
                //'actions' => $this->build_actions($member->id)
            ];
        }
        $this->items = $data;
    }

    function build_name_with_modal($member)
    {
        $output = "<a href=\"#TB_inline?1=1&inlineId=more_details_{$member->id}\"  title=\"Contact Data\" class=\"thickbox\">{$member->display_name}</a>";
        $output = $member->display_name;

        $output .= "<div id=\"more_details_{$member->id}\" style=\"display:none;\">";
        $output .= " <div class=\"details_row\"><label>Name:</label> <div>{$member->display_name}</div></div>";
        $output .= " <div class=\"details_row\"><label>Email:</label> <div>{$member->user_email}</div></div>";
        $output .= " <div class=\"details_row\"><label>Phone:</label> <div>{$member->meta['mepr_practice_phone'][0]}</div></div>";
        $mpi = MemberPressInterface::getInstance();
        $type = $mpi->member_types[$member->meta['mepr_member_type'][0]] ?? $member->meta['mepr_member_type'][0];

        $output .= " <div class=\"details_row\"><label>Member Type:</label> <div>{$type}</div></div>";
        $output .= " <div class=\"details_row\"><label>Referred By:</label> <div>{$member->meta['mepr_referred_by'][0]}</div></div>";
        $output .= " <div class=\"details_row\"><label>Referral Name:</label> <div>{$member->meta['mepr_referring_rep_name'][0]}</div></div>";
        $output .= " <hr/>";
        $output .= " <div class=\"details_row\"><label>Practice Name:</label> <div>{$member->meta['mepr_practice_name'][0]}</div></div>";
        $output .= " <div class=\"details_row\"><label>Practice Website:</label> <div>{$member->meta['mepr_website'][0]}</div></div>";
        $output .= " <hr/>";
        $location_1 = $this->format_address($member->meta['mepr-address-one'][0], $member->meta['mepr-address-two'][0], $member->meta['mepr-address-city'][0], $member->meta['mepr-address-state'][0], $member->meta['mepr-address-zip'][0]);
        $output .= " <div class=\"details_row\"><label>Location 1:</label> <div>{$location_1}</div></div>";
        $location_2 = $this->format_address($member->meta['mepr_location_1_address_1'][0], $member->meta['mepr_location_1_address_2'][0], $member->meta['mepr_location_1_city'][0], $member->meta['mepr_location_1_state'][0], $member->meta['mepr_location_1_zip'][0]);
        $output .= " <div class=\"details_row\"><label>Location 2:</label> <div>{$location_2}</div></div>";
        $location_3 = $this->format_address($member->meta['mepr_location_2_address_1'][0], $member->meta['mepr_location_2_address_2'][0], $member->meta['mepr_location_2_city'][0], $member->meta['mepr_location_2_state'][0], $member->meta['mepr_location_2_zip'][0]);
        $output .= " <div class=\"details_row\"><label>Location 3:</label> <div>{$location_3}</div></div>";

        $output .= " <div class=\"modal_actions\">";
        $output .= " <a href=\"#\" class=\"button deny_member\" data-member_id=\"{$member->id}\">Deny</a>";
        $output .= " <a href=\"#\" class=\"button approve_member\" data-member_id=\"{$member->id}\">Approve</a>";
        $output .= " <img src=\"/wp-admin/images/wpspin_light-2x.gif\" class=\"action_wait\" />";
        $output .= " <div class=\"status\"></div>";
        $output .= " </div>";
        //$output .= "<pre>" . var_export($member, true) . "</pre>";
        $output .= "</div>";
        return $output;
    }

    function format_address($ad1, $ad2, $city, $state, $zip)
    {
        $output = '';
        if ($ad1) $output .= $ad1 . '<br/>';
        if ($ad2) $output .= $ad2 . '<br/>';
        if ($city) $output .= $city . ', ';
        if ($state) $output .= $state . ' &nbsp; ';
        if ($zip) $output .= $zip;
        return $output;
    }

    function build_actions($member_id)
    {
        $output = "<div class=\"auth_actions\">";
        $output .= " <a href=\"#\" class=\"button deny_member\" data-member_id=\"{$member_id}\">Deny</a>";
        $output .= " <a href=\"#\" class=\"button approve_member\" data-member_id=\"{$member_id}\">Approve</a>";
        $output .= " <img src=\"/wp-admin/images/wpspin_light-2x.gif\" class=\"action_wait\" />";
        $output .= " <div class=\"status\"></div>";
        $output .= "</div>";
        return $output;
    }
}
