<?php

/**
 * SalesforceConnector
 *
 * Handles integration between WordPress and Salesforce for the ECR Options plugin.
 * Provides methods for authentication, querying, and CRUD operations on Salesforce objects
 * such as Account, Contact, and Location. Uses Guzzle for HTTP requests and logs all
 * requests and responses to a custom database table for debugging and auditing.
 *
 * Key Features:
 * - OAuth2 authentication and token refresh for Salesforce API access.
 * - Singleton pattern to ensure a single connector instance.
 * - Methods to create, update, and query Salesforce Account, Contact, and Location records.
 * - Guzzle middleware for logging all API requests and responses.
 * - WordPress REST endpoint for Salesforce OAuth callback.
 *
 * @package   ECROptions
 * @author    Your Name
 * @copyright Copyright (c) 2025
 * @license   GPL-2.0+
 */

namespace ECROptions;

use WP_REST_Request;
use GuzzleHttp\Client;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Middleware;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;

/**
 * 
 * Using a singleton instance of this class keeps the rest endpoint from being called when it's not supposed to be
 * 
 */
class SalesforceConnector
{

    private static $instance = null;

    private $clientId;
    private $clientSecret;
    private $instanceUrl;
    private $callback;
    private $api_version;
    private $siteUrl;
    private $stack;


    public $auth;

    /**
     * Returns the singleton instance of the SalesforceConnector.
     *
     * @return SalesforceConnector The singleton instance.
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * SalesforceConnector constructor.
     *
     * Initializes Guzzle handler stack, loads Salesforce credentials, sets up REST endpoint, and prepares callback URL.
     */
    function __construct()
    {
        $this->build_guzzle_log_handler();

        $this->api_version = 'v60.0';

        $this->auth = get_option('ecr-options-salesforce-authorization');

        // Current credentials for "ECR Web Connector" app
        $this->clientId = '3MVG9dAEux2v1sLt952_kbmW_b0ewNl9kLO1FOmJMV.rL339IJEG0dZOC..k2he24rsyJzodV6yZQbj9Urtwg';
        $this->clientSecret = '894A9B5016D588CA7F2CB7693D84588278AE66012EAB4840614D2962D791BF55';
        $this->instanceUrl = 'https://orgfarm-95e3b5c9c5-dev-ed.develop.my.salesforce.com';
        $this->siteUrl = 'https://agility-power-9630.my.salesforce.com/';

        // all variables above need to be eventually changable via an option form
        $this->callback = home_url() . '/wp-json/ecr-options/v1/sfcallback';

        // we need a custom endpoint for salesforce to talk back to us
        add_action('rest_api_init', function () {
            register_rest_route('ecr-options/v1', '/sfcallback', array(
                'methods' => 'GET',
                'callback' => [$this, 'process_salesforce_callback'],
                'permission_callback' => '__return_true',
            ));
        });
    }


    /**
     * Builds the Guzzle handler stack with middleware for logging requests and responses to the database.
     *
     * @return void
     */
    function build_guzzle_log_handler()
    {
        global $wpdb;
        // make sure the database exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}eco_guzzle_log'") != "{$wpdb->prefix}eco_guzzle_log") {
            $this->create_guzzle_log();
        }

        // build the guzzle handlerstack to log requests and responses
        $this->stack = HandlerStack::create();

        $this->stack->push(Middleware::mapResponse(function (ResponseInterface $response) {
            global $wpdb;
            $wpdb->query(
                $wpdb->prepare("INSERT INTO {$wpdb->prefix}eco_guzzle_log (type, status_code, headers, body) VALUES (%s, %s, %s, %s)", [
                    'response',
                    $response->getStatusCode(),
                    json_encode($response->getHeaders()),
                    (string) $response->getBody()
                ])
            );
            return $response;
        }));

        $this->stack->push(Middleware::mapRequest(function (RequestInterface $request) {
            global $wpdb;
            $wpdb->query(
                $wpdb->prepare("INSERT INTO {$wpdb->prefix}eco_guzzle_log (type, method, uri, headers, body) VALUES (%s, %s, %s, %s, %s)", [
                    'request',
                    $request->getMethod(),
                    (string) $request->getUri(),
                    json_encode($request->getHeaders()),
                    (string) $request->getBody()
                ])
            );
            return $request;
        }));
    }

    /**
     * Creates the database table for logging Guzzle requests and responses if it does not exist.
     *
     * @return void
     */
    function create_guzzle_log()
    {
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $sql = "CREATE TABLE {$wpdb->prefix}eco_guzzle_log (
            ID mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
            type varchar(255) NOT NULL,
            status_code varchar(255) NOT NULL,
            method varchar(255) NOT NULL,
            uri varchar(255) NOT NULL,
            headers text NOT NULL,
            body mediumtext NOT NULL,
            timestamp datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY  (ID)
        );";

        dbDelta($sql);
    }

    /**
     * Generates the Salesforce OAuth2 authorization URL for connecting the app.
     *
     * @return string The Salesforce OAuth2 authorization URL.
     */
    function get_connect_link()
    {
        $link = "{$this->siteUrl}/services/oauth2/authorize?client_id={$this->clientId}&redirect_uri={$this->callback}&response_type=code";
        return $link;
    }

    /**
     * Generates the disconnect URL for Salesforce, used to remove the connection.
     *
     * @return string The disconnect URL.
     */
    function get_disconnect_link()
    {
        $link = "{$this->callback}?mode=disconnect";
        return $link;
    }

    /**
     * Processes the Salesforce OAuth2 callback and stores the authorization data in WordPress options.
     *
     * @param WP_REST_Request $request The REST request object.
     * @return void
     */
    function process_salesforce_callback(WP_REST_Request $request)
    {
        // if there is a code variable in the url, this is an authorization callback
        if ($_GET['code']) {
            try {
                $client = new Client(['handler' => $this->stack]);
                $response = $client->post($this->siteUrl . '/services/oauth2/token', [
                    'form_params' => [
                        'grant_type'    => 'authorization_code',
                        'code'          => $_GET['code'],
                        'client_id'     => $this->clientId,
                        'client_secret' => $this->clientSecret,
                        'redirect_uri'  => $this->callback
                    ],
                ]);

                $this->auth = json_decode($response->getBody(), true);

                // load up WP so we can store the data
                require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

                update_option('ecr-options-salesforce-authorization', $this->auth);

                header('Content-Type: text/html; charset=utf-8');
                echo "<script type='text/javascript'>";
                echo "window.opener.reload();";
                echo "window.close();";
                echo "</script>";
            } catch (\Exception $e) {
                header('Content-Type: text/html; charset=utf-8');
                echo '<h2>Authentication failed: ' . $e->getMessage() . '</h2>';
                echo '<div>Please try again.</div>';
            }
        }
    }

    /**
     * Executes a SOQL query against Salesforce and returns the result.
     * Automatically attempts to refresh the token if the session is invalid.
     *
     * @param string $qry The SOQL query string.
     * @return array|string The query result as an array, or an error message string.
     */
    function query($qry)
    {
        // if auth is false, we don't have a connection...
        if (!$this->auth) {
            return "<b>ERROR:</b> Please reconnect Salesforce!";
        }

        $client = new Client([
            'handler' => $this->stack,
            'base_uri' => "{$this->siteUrl}/services/data/{$this->api_version}/",
        ]);

        try {
            $data = $client->get("query", [
                'headers' => [
                    'Authorization' => "Bearer " . $this->auth['access_token'],
                ],
                'query' => [
                    'q' => $qry
                ]
            ]);
            return json_decode($data->getBody(), true);
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            $response = $e->getResponse();
            $body = json_decode($response->getBody(), true);

            if (isset($body[0]['errorCode']) && $body[0]['errorCode'] === 'INVALID_SESSION_ID') {
                // We need to try to refresh the token
                if ($this->refresh_token()) {
                    // only queries need to be run again, as other methods call query first anyways
                    try {
                        $data = $client->get("query", [
                            'headers' => [
                                'Authorization' => "Bearer " . $this->auth['access_token'],
                            ],
                            'query' => [
                                'q' => $qry
                            ]
                        ]);
                        return json_decode($data->getBody(), true);
                    } catch (\Exception $e) {
                        return "<b>ERROR:</b> Please reconnect Salesforce!";
                    }
                }
            }
        } catch (\Exception $e) {
            return "<b>ERROR:</b> Please reconnect Salesforce!";
        }
    }

    /**
     * Attempts to refresh the Salesforce OAuth2 access token using the refresh token.
     * Updates the stored authorization data on success.
     *
     * @return bool True on success, false on failure.
     */
    function refresh_token()
    {
        if (!$this->auth) {
            return false;
        }

        try {
            $client = new Client(['handler' => $this->stack]);
            $data = $client->post($this->siteUrl . 'services/oauth2/token', [
                'form_params' => [
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $this->clientId,
                    'client_secret' => $this->clientSecret,
                    'refresh_token' => $this->auth['refresh_token'],
                ],
            ]);
            $newauth = json_decode($data->getBody(), true);

            // update the existing auth, but only replace what's new (EX: refresh_token is not provided again)
            $this->auth = array_replace($this->auth, $newauth);

            // load up WP so we can store the data
            require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');
            update_option('ecr-options-salesforce-authorization', $this->auth);

            return true;
        } catch (\Exception $e) {
            echo "<p>Issue refreshing token: " . $e->getMessage() . "<p>";
            return false;
        }
    }

    /**
     * Saves or updates a Salesforce Account record for the specified user.
     * If the account exists and $overwrite is false, returns the existing Account ID.
     *
     * @param int  $user_id   The WordPress user ID.
     * @param bool $overwrite Whether to overwrite an existing Account (default: false).
     * @return array Returns an array with 'status', 'message', and optionally 'account_id' keys.
     */
    function save_account($user_id, $overwrite = false)
    {
        // get the user's data by his id
        $user_data = get_user_meta($user_id);
        $user_data['Email'] = get_userdata($user_id)->user_email;

        // if there is no practice name, we can't create an account
        if (!isset($user_data['mepr_practice_name'][0]) || empty($user_data['mepr_practice_name'][0])) {
            // because practice name is not set, we return blank for the account id
            return ['status' => 'success', 'message' => 'Practice Name does not exist.', 'account_id' => ''];
        }

        // query for the practice name to see if it exists in Salesforce
        $qres = $this->query("SELECT Id FROM Account WHERE Name = '{$user_data['mepr_practice_name'][0]}'");

        if ($qres['totalSize'] > 0 && $overwrite == false) {
            // return the existing account id
            return ['status' => 'success', 'message' => "Account exists: {$qres['records'][0]['Id']}", 'account_id' => $qres['records'][0]['Id']];
        } else {
            // talk to salesforce
            $client = new Client(['handler' => $this->stack, 'base_uri' => "{$this->siteUrl}/services/data/{$this->api_version}/"]);

            try {
                $options = [
                    'headers' => [
                        'Authorization' => "Bearer " . $this->auth['access_token'],
                        'Content-Type'  => 'application/json'
                    ],
                    'json' => [
                        'Name' => $user_data['mepr_practice_name'][0],
                        'Phone' => $user_data['mepr_practice_phone'][0],
                        'Website' => $user_data['mepr_website'][0],
                        'BillingStreet' => $user_data['mepr-address-one'][0] . "\n" . $user_data['mepr-address-two'][0],
                        'BillingCity' => $user_data['mepr-address-city'][0],
                        'BillingState' => $user_data['mepr-address-state'][0],
                        'BillingPostalCode' => $user_data['mepr-address-zip'][0],
                        'ECR_Member_ID__c' => $user_id
                    ]
                ];

                if ($qres['totalSize'] == 0) { // we need to create a new account
                    $data = $client->post("sobjects/Account/", $options);

                    $res = json_decode($data->getBody(), true);

                    if ($res['success']) {
                        return [
                            'status' => 'success',
                            'message' => 'Account saved',
                            'account_id' => $res['id']
                        ];
                    } else {
                        // error creating account
                        return [
                            'status' => 'error',
                            'message' => 'Salesforce Error: ' . var_export($res, true)
                        ];
                    }
                } else { // we need to update the existing account
                    $data = $client->patch("sobjects/Account/{$qres['records'][0]['Id']}", $options);

                    if ($data->getStatusCode() == 204) {
                        // success, no content returned on a patch
                        return [
                            'status' => 'success',
                            'message' => 'Account updated',
                            'account_id' => $qres['records'][0]['Id']
                        ];
                    } else {
                        $body = $data->getBody();
                        $errorData = json_decode($body, true);
                        return [
                            'status' => 'error',
                            'message' => 'Salesforce Error: ' . var_export($errorData, true)
                        ];
                    }
                }
            } catch (\Exception $e) {
                return [
                    'status' => 'error',
                    'message' => 'Salesforce Error: ' . $e->getMessage()
                ];
            }
        }
    }

    /**
     * Saves or updates a Salesforce Contact record for the specified user.
     * If the contact exists and $overwrite is false, returns the existing Contact ID.
     *
     * @param int    $user_id    The WordPress user ID.
     * @param string $account_id (Optional) The Salesforce Account ID to associate with the Contact.
     * @param bool   $overwrite  Whether to overwrite an existing Contact (default: false).
     * @return array Returns an array with 'status', 'message', and optionally 'contact_id' or 'account_id' keys.
     */
    function save_contact($user_id, $account_id = '', $overwrite = false)
    {
        // get the user's data by his id
        $user_data = get_user_meta($user_id);
        $user_data['user_email'] = get_userdata($user_id)->user_email;

        // if there is no last name or email, we can't create a contact
        if (!isset($user_data['last_name'][0]) || empty($user_data['last_name'][0]) || !isset($user_data['user_email']) || empty($user_data['user_email'])) {
            return ['status' => 'error', 'message' => 'Last Name or Email does not exist.'];
        }

        // query for the email to see if it exists in Salesforce
        $qres = $this->query("SELECT Id FROM Contact WHERE Email = '{$user_data['user_email']}' AND LastName = '{$user_data['last_name'][0]}'");

        if ($qres['totalSize'] > 0 && $overwrite == false) {
            // return the existing contact id
            return ['status' => 'success', 'message' => "Contact exists: {$qres['records'][0]['Id']}", 'contact_id' => $qres['records'][0]['Id']];
        } else {
            // talk to salesforce
            $client = new Client(['handler' => $this->stack, 'base_uri' => "{$this->siteUrl}/services/data/{$this->api_version}/"]);

            try {
                $options = [
                    'headers' => [
                        'Authorization' => "Bearer " . $this->auth['access_token'],
                        'Content-Type'  => 'application/json'
                    ],
                    'json' => [
                        'FirstName' => $user_data['first_name'][0],
                        'LastName' => $user_data['last_name'][0],
                        'Email' => $user_data['user_email'],
                        'MailingStreet' => $user_data['mepr-address-one'][0] . "\n" . $user_data['mepr-address-two'][0],
                        'MailingCity' => $user_data['mepr-address-city'][0],
                        'MailingState' => $user_data['mepr-address-state'][0],
                        'MailingPostalCode' => $user_data['mepr-address-zip'][0],
                        'direct_phone__c' => $user_data['mepr_practice_phone'][0], // I DON'T THINK WE NEED DIRECT PHONE, PRACTICE PHONE SHOULD MAP TO ACCOUNT NOT CONTACT
                        'Phone' => $user_data['mepr_practice_phone'][0], // WE MIGHT WANT TO RETHINK HOW THIS IS SETUP. We may need a regular phone field for contact and practice phone for account
                        'Member_Type__c' => $user_data['mepr_member_type'][0], // SF-Picklist
                        'Member__c' => true, // SF-Boolean
                        'Member_ID__c' => $user_id,
                        'AccountId' => $account_id
                    ]
                ];

                if ($qres['totalSize'] == 0) { // we need to create a new contact
                    $data = $client->post("sobjects/Contact/", $options);

                    $res = json_decode($data->getBody(), true);

                    if ($res['success']) {
                        return [
                            'status' => 'success',
                            'message' => 'Contact saved',
                            'account_id' => $res['id']
                        ];
                    } else {
                        // error creating contact
                        return [
                            'status' => 'error',
                            'message' => 'Salesforce Error: ' . var_export($res, true)
                        ];
                    }
                } else { // we need to update the existing contact
                    $data = $client->patch("sobjects/Contact/{$qres['records'][0]['Id']}", $options);

                    if ($data->getStatusCode() == 204) {
                        // success, no content returned on a patch
                        return [
                            'status' => 'success',
                            'message' => 'Contact updated',
                            'contact_id' => $qres['records'][0]['Id']
                        ];
                    } else {
                        $body = $data->getBody();
                        $errorData = json_decode($body, true);
                        return [
                            'status' => 'error',
                            'message' => 'Salesforce Error: ' . var_export($errorData, true)
                        ];
                    }
                }
            } catch (\Exception $e) {
                return [
                    'status' => 'error',
                    'message' => 'Salesforce Error: ' . $e->getMessage()
                ];
            }
        }
    }

    /**
     * Saves or updates a Salesforce Location record for the specified user.
     *
     * Builds the location data based on the provided type and user meta, then creates or updates
     * the Location record in Salesforce. If a primary location already exists for the account,
     * additional locations are created as needed. Handles both creation and update logic, and
     * ensures only one primary location per account.
     *
     * @param int         $user_id     The WordPress user ID.
     * @param string|null $type        The location type ("P" for primary, "A1" or "A2" for additional).
     * @param string|null $account_id  The Salesforce Account ID to associate with the location.
     * @param string|null $contact_id  The Salesforce Contact ID to associate with the location.
     * @param bool        $overwrite   Whether to overwrite an existing location (default: false).
     *
     * @return array Returns an array with 'status', 'message', and optionally 'location_id' keys indicating the result.
     */
    function save_location($user_id, $type = null, $account_id = null, $contact_id = null, $overwrite = false)
    {
        $location_fields = [];
        $no_primary = false;

        // get the user's data by his id
        $user_data = get_user_meta($user_id);
        //$user_data['user_email'] = get_userdata($user_id)->user_email;

        // we need to build the data set to use based on the type of location
        switch ($type) {
            case "P":
                $location_fields['Name'] = $user_data['mepr_practice_name'][0] ?? '';
                $location_fields['LocationType'] = "Primary Location";
                $location_fields['Address_Line_1__c'] = $user_data['mepr-address-one'][0] ?? '';
                $location_fields['Address_Line_2__c'] = $user_data['mepr-address-two'][0] ?? '';
                $location_fields['City__c'] = $user_data['mepr-address-city'][0] ?? '';
                $location_fields['State__c'] = $user_data['mepr-address-state'][0] ?? '';
                $location_fields['ZipCode__c'] = $user_data['mepr-address-zip'][0] ?? '';
                break;
            case "A1":
                $location_fields['Name'] = $user_data['mepr_practice_name'][0] ?? '';
                $location_fields['LocationType'] = "Additional Location";
                $location_fields['Address_Line_1__c'] = $user_data['mepr_location_1_address_1'][0] ?? '';
                $location_fields['Address_Line_2__c'] = $user_data['mepr_location_1_address_2'][0] ?? '';
                $location_fields['City__c'] = $user_data['mepr_location_1_city'][0] ?? '';
                $location_fields['State__c'] = $user_data['mepr_location_1_state'][0] ?? '';
                $location_fields['ZipCode__c'] = $user_data['mepr_location_1_zip'][0] ?? '';
                break;
            case "A2":
                $location_fields['Name'] = $user_data['mepr_practice_name'][0] ?? '';
                $location_fields['LocationType'] = "Additional Location";
                $location_fields['Address_Line_1__c'] = $user_data['mepr_location_2_address_1'][0] ?? '';
                $location_fields['Address_Line_2__c'] = $user_data['mepr_location_2_address_2'][0] ?? '';
                $location_fields['City__c'] = $user_data['mepr_location_2_city'][0] ?? '';
                $location_fields['State__c'] = $user_data['mepr_location_2_state'][0] ?? '';
                $location_fields['ZipCode__c'] = $user_data['mepr_location_2_zip'][0] ?? '';
                break;
            default:
                return ['status' => 'error', 'message' => 'Location type not recognized.'];
        }

        // if there is no practice name or address line one, we can't create a contact
        if (!isset($location_fields['Name']) || empty($location_fields['Name']) || !isset($location_fields['Address_Line_1__c']) || empty($location_fields['Address_Line_1__c'])) {
            return ['status' => 'success', 'message' => 'No location to add.'];
        }

        // add address line 1 to the name to make it unique
        $location_fields['Name'] .= ' - ' . $location_fields['Address_Line_1__c'];

        // we need to query if there is already a primary location for this account
        if ($type == "P" && $account_id) {
            $qres = $this->query("SELECT Id FROM Location WHERE Account__c = '{$account_id}' AND LocationType = 'Primary Location'");
            if ($qres['totalSize'] > 0) {
                // we found an existing primary location, switch this to an Additional Location
                $location_fields['LocationType'] = "Additional Location";
            } else {
                $no_primary = true;
            }
        }

        // query for the name to see if it exists in Salesforce
        $qres = $this->query("SELECT Id FROM Location WHERE Name = '{$location_fields['Name']}'");

        if ($qres['totalSize'] > 0 && $overwrite == false) {
            // if there is no primary location, we need to fix it
            if ($no_primary) {
                $res = $this->set_primary_location($qres['records'][0]['Id']);
            }

            // return the existing contact id
            return ['status' => 'success', 'message' => "Location exists: {$qres['records'][0]['Id']}", 'location_id' => $qres['records'][0]['Id']];
        } else {
            // talk to salesforce
            $client = new Client(['handler' => $this->stack, 'base_uri' => "{$this->siteUrl}/services/data/{$this->api_version}/"]);

            try {
                $options = [
                    'headers' => [
                        'Authorization' => "Bearer " . $this->auth['access_token'],
                        'Content-Type'  => 'application/json'
                    ],
                    'json' => array_merge($location_fields, [
                        'Account' => $account_id,
                        'Contact' => $contact_id
                    ])
                ];

                if ($qres['totalSize'] == 0) { // we need to create a new location
                    $data = $client->post("sobjects/Location/", $options);

                    $res = json_decode($data->getBody(), true);

                    if ($res['success']) {
                        return [
                            'status' => 'success',
                            'message' => 'Location saved',
                            'location_id' => $res['id']
                        ];
                    } else {
                        // error creating location
                        return [
                            'status' => 'error',
                            'message' => 'Salesforce Error: ' . var_export($res, true)
                        ];
                    }
                } else { // we need to update the existing location
                    $data = $client->patch("sobjects/Location/{$qres['records'][0]['Id']}", $options);

                    if ($data->getStatusCode() == 204) {
                        // success, no content returned on a patch
                        return [
                            'status' => 'success',
                            'message' => 'Location updated',
                            'location_id' => $qres['records'][0]['Id']
                        ];
                    } else {
                        $body = $data->getBody();
                        $errorData = json_decode($body, true);
                        return [
                            'status' => 'error',
                            'message' => 'Salesforce Error: ' . var_export($errorData, true)
                        ];
                    }
                }
            } catch (\Exception $e) {
                return [
                    'status' => 'error',
                    'message' => 'Salesforce Error: ' . $e->getMessage()
                ];
            }
        }
    }

    /**
     * Switches the specified Salesforce Location record to "Primary Location" type.
     *
     * Sends a PATCH request to Salesforce to update the LocationType field of the given Location record to "Primary Location".
     *
     * @param string $location_id The Salesforce Location record ID to update.
     * @return array Returns an array with 'status', 'message', and optionally 'location_id' keys indicating the result.
     */
    function set_primary_location($location_id)
    {
        // we need to update this location to be the primary location
        $client = new Client(['handler' => $this->stack, 'base_uri' => "{$this->siteUrl}/services/data/{$this->api_version}/"]);

        try {
            $options = [
                'headers' => [
                    'Authorization' => "Bearer " . $this->auth['access_token'],
                    'Content-Type'  => 'application/json'
                ],
                'json' => [
                    'LocationType' => 'Primary Location'
                ]
            ];

            $data = $client->patch("sobjects/Location/{$location_id}", $options);

            if ($data->getStatusCode() == 204) {
                // success, no content returned on a patch
                return [
                    'status' => 'success',
                    'message' => 'Location updated to Primary Location'
                ];
            } else {
                $body = $data->getBody();
                $errorData = json_decode($body, true);
                return [
                    'status' => 'error',
                    'message' => 'Salesforce Error: ' . var_export($errorData, true)
                ];
            }
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Salesforce Error: ' . $e->getMessage()
            ];
        }
    }
}
