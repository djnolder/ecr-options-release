<?php

namespace ECROptions;

use GuzzleHttp\Client;

class AdminPageTabSalesforce
{

    function __construct() {}

    function render()
    {
        $sfc = SalesforceConnector::getInstance();

        $tvars['connect_link'] = $sfc->get_connect_link();
        $tvars['disconnect_link'] = $sfc->get_disconnect_link();

        $data = $sfc->query("SELECT AccountId,Account.Name,Name,Email,MailingAddress,Phone,Member_Type__c FROM Contact WHERE Account.Type = 'Member'");

        // if the query didn't return an array, then it retured a string indicating why.
        if (!is_array($data)) {
            $tvars['contacts_error'] = $data;
        } else {
            $tvars['contacts_count'] = count($data['records']);

            $all_sf = [];
            $sf_only = [];
            foreach ($data['records'] as $record) {
                $all_sf[] = $record['Email'];
                if (!$u = get_user_by_email($record['Email'])) {
                    $sf_only[] = $record;
                }
            }
            $tvars['sf_only'] = $sf_only;

            $users = get_users();
            $mp_only = [];
            foreach ($users as $u) {
                if (!in_array($u->user_email, $all_sf)) {
                    $u->metadata = get_user_meta($u->ID);
                    $mp_only[] = $u;
                }
            }
            $tvars['users_count'] = count($users);
            $tvars['mp_only'] = $mp_only;
        }

        Main::get_template('AdminPageTabSFConnect', $tvars);
    }
}

// connect to SF



            /*



            // Salesforce API credentials
            $clientId = 'YOUR_CONSUMER_KEY';
            $clientSecret = 'YOUR_CONSUMER_SECRET';
            $username = 'YOUR_SALESFORCE_USERNAME';
            $password = 'YOUR_SALESFORCE_PASSWORD_AND_SECURITY_TOKEN'; // Password + Security Token

            // Salesforce instance URL (e.g., https://yourinstance.my.salesforce.com)
            $instanceUrl = 'YOUR_SALESFORCE_INSTANCE_URL';

            

            // 2. Pull Contacts using SOQL Query
            try {
                $query = 'SELECT Id, FirstName, LastName, Email, Phone FROM Contact';
                $response = $client->get($instanceUrl . '/services/data/v58.0/query', [ // Adjust API version as needed
                    'headers' => [
                        'Authorization' => 'Bearer ' . $accessToken,
                    ],
                    'query' => [
                        'q' => $query,
                    ],
                ]);

                $contactsData = json_decode($response->getBody(), true);

                if (isset($contactsData['records'])) {
                    foreach ($contactsData['records'] as $contact) {
                        echo "ID: " . $contact['Id'] . ", Name: " . $contact['FirstName'] . " " . $contact['LastName'] . ", Email: " . $contact['Email'] . "\n";
                    }
                } else {
                    echo "No contacts found or unexpected response.\n";
                }
            } catch (Exception $e) {
                echo 'Error pulling contacts: ' . $e->getMessage();
            }*/
