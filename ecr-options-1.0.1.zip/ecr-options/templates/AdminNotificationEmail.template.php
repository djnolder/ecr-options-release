<h2>New Signup Notification</h2>
<p>A new user just signed up on your site:</p>
<table cellpadding="6" cellspacing="0" style="margin-bottom: 20px;">
    <tr>
        <th align="left">ID:</th>
        <td><?= $user_id ?></td>
    </tr>
    <tr>
        <th align="left">Name:</th>
        <td><?= $user_first_name ?> <?= $user_last_name ?></td>
    </tr>
    <tr>
        <th align="left">Email:</th>
        <td><?= $user_email ?></td>
    </tr>
    <tr>
        <th align="left">Practice Name:</th>
        <td><?= $practice_name ?></td>
    </tr>
    <tr>
        <th align="left">Member Type:</th>
        <td><?= $member_type_name ?></td>
    </tr>
    <tr>
        <th align="left">Phone:</th>
        <td><?= $phone ?></td>
    </tr>
    <tr>
        <th align="left">Website:</th>
        <td><?= $website ?></td>
    </tr>
    <tr>
        <th align="left">Referred By:</th>
        <td><?= $referred_by ?></td>
    </tr>
    <tr>
        <th align="left">Referring Rep Name:</th>
        <td><?= $referring_rep_name ?></td>
    </tr>
    <tr>
        <th align="left">Address:</th>
        <td><?= $user_address ?></td>
    </tr>
</table>