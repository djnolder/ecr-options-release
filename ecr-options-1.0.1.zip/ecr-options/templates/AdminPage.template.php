<div class="wrap">
    <h2>ECR Utilities</h2>
    <p>This page will be use for any custom ECR utilities. Like the user authentication system.</p>

    <h2 class="nav-tab-wrapper">
        <?php
        $tab_link = '';
        foreach ($tabs as $tab => $data) :
            $active = $_GET['tab'] == $tab ? 'nav-tab-active' : '';
            if ($tab) $tab_link = "&tab=" . $tab;
        ?>
            <a href="?page=ect-utilities<?= $tab_link ?>" class="nav-tab <?= $active ?>" data-tab="<?= $tab ?>" data-tab_class="<?= $data['class'] ?>"><?= $data['name'] ?></a>
        <?php endforeach; ?>
    </h2>

    <div id="tab-inner">
        <?= $class_render ?>
    </div>

</div>