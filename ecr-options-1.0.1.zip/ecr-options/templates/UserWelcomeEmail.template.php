<html>

<body style="font-family: Arial, sans-serif; color: #333;">
    <div style="max-width: 680px; margin: 0 auto; padding: 20px;">
        <h1 style="font-size: 24px;">Dear <?= $user_first_name ?>,</h1>

        <p>Thank you for being an Eyecare Republic member... <i>the next generation of Doctor's Alliance Groups!</i> We are thrilled to have you as part our growing community of forward-thinking eye care professionals. Our goal is to empower ECPs through unbiased partnerships and solutions. You will always have options at Eyecare Republic that match your vision for your practice.</p>

        <p>Your immediate benefits are unlocked:</p>
        <ul>
            <li>B+L exclusive program with an Elite contact lens partnership (likely the reason you joined us!) Let’s make sure you are on our ECR/B+L program</li>
            <li>Growing Vendor Network</li>
            <li>Lab and frame partnerships</li>
            <li>Access to Optometry 411 and ECR Newsletter</li>
            <li><b>0$ Membership Fees</b></li>
        </ul>

        <p>There will be more to come in our vendor portfolio, and our vendors will always be selected based on member value, not corporate ownership. We will always look for your feedback and we are excited to announce that there will be exclusive opportunities ahead. So, stay tuned while we work our magic to reimagine practice differentiation.</p>

        <p>I look forward to connecting with you! Please schedule your initial onboarding with me today using my link: <a href="https://calendly.com/rshallin-eyecarerepublic">15-minute Onboarding</a></p>

        <p>Sincerely,</p>

        <p>Rita,</p>

        <table border=0 cellspacing=0 cellpadding=0 width=0 style='border-collapse:collapse'>
            <tr>
                <td rowspan=3 style='border-right:solid #D9D9D9 1.0pt;padding-right: 5pt;'>
                    <img border=0 width=97 height=79 src="/wp-content/plugins/ecr-options/img/logo_for_email.png" alt="ECR Logo">
                </td>
                <td style="padding-left: 5pt;">
                    <div style='margin-bottom:0in'><b>Rita Shallin</b></div>
                    <div style='margin-bottom:0in'>Director, Business Development&nbsp;</div>
                </td>
            </tr>
            <tr>
                <td style="padding-left: 5pt;">
                    <div style='margin-bottom:0in'>Mobile <b><a href="tel:+12034511525">203-451-1525</a></b>&nbsp;</div>
                </td>
            </tr>
            <tr>
                <td style="padding-left: 5pt;">
                    <a href="https://www.facebook.com/share/WK5gfdWas3LnJsbr/?mibextid=LQQJ4d"><img border=0 width=19 height=19 src="/wp-content/plugins/ecr-options/img/facebook_for_email.png" alt="Facebook Link" /></a>
                    &nbsp;
                    <a href="https://x.com/ECRepublic"><img border=0 width=19 height=19 src="/wp-content/plugins/ecr-options/img/twitter_for_email.png" alt="Twitter Link" /></a>
                    &nbsp;
                    <a href="https://www.instagram.com/eyecare.republic/"><img border=0 width=19 height=19 src="/wp-content/plugins/ecr-options/img/instagram_for_email.png" alt="Instagram Link" /></a>
                    &nbsp;
                    <a href="https://www.linkedin.com/company/99421261/"><img border=0 width=19 height=19 src="/wp-content/plugins/ecr-options/img/linkedin_for_email.png" alt="LinkedIn Link"></a>
                </td>
            </tr>
        </table>
    </div>
</body>

</html>