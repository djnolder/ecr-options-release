<?php

namespace ECROptions;

class AdminPageTabMain
{

    function __construct() {}

    function render()
    {
        echo "<p style=\"font-size: 30px;\">NOTE: These admin pages are still being built.</p>";
    }
}
