<?php

namespace ECROptions;

class AJAX
{

    static function get_tab_content()
    {
        $class_name = '\ECROptions\\' . $_POST['tab-class'];
        $tab_class = new $class_name();
        $tab_class->render();
        wp_die();
    }

    static function approve_member()
    {
        $output = [
            'status' => 'success',
            'message' => '',
        ];

        $sfc = new SalesforceConnector();

        // Create a new Salesforce account
        $res = $sfc->save_account($_POST['member_id']);
        // we don't really care if account doesn't save, just pull the account_id if it exists
        $account_id = $res['account_id'] ?? '';
        $output['message'] .= $res['message'] . " | " ?? '';

        // Create a new Salesforce contact
        // Go back to account and update Primary Contact ID, if applicable
        $res = $sfc->save_contact($_POST['member_id'], $account_id);
        if ($res['status'] != 'success') {
            // exit if contact doesn't save
            wp_die(json_encode($res));
        }
        $contact_id = $res['contact_id'] ?? '';
        $output['message'] .= $res['message'] . " | " ?? '';

        // Create a new Salesforce location based on primary data
        $res = $sfc->save_location($_POST['member_id'], 'P', $account_id, $contact_id);
        $output['message'] .= $res['message'] . " | " ?? '';

        // Create a new Salesforce location 1st additional location data
        $res = $sfc->save_location($_POST['member_id'], 'A1', $account_id, $contact_id);
        $output['message'] .= $res['message'] . " | " ?? '';

        // Create a new Salesforce location 2nd additional location data
        $res = $sfc->save_location($_POST['member_id'], 'A2', $account_id, $contact_id);
        $output['message'] .= $res['message'] . " | " ?? '';

        // now we need to add a transaction to the member, thus flagging him active
        $mpi = new MemberPressInterface();
        $res = $mpi->manually_add_transaction($_POST['member_id'], 3307);
        if ($res['status'] != 'success') {
            // exit if transaction doesn't save
            wp_die(json_encode($res));
        }
        $output['message'] .= $res['message'] ?? '';

        wp_die(json_encode($output));
    }
}
