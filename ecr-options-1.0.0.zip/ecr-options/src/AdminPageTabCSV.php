<?php

namespace ECROptions;

class AdminPageTabCSV
{


    function __construct() {}

    function render()
    {

?>
        <div id="poststuff" class="postbox-container">
            <div class="postbox">
                <div class="postbox-header">
                    <h2>Upload member list CSV for importing</h2>
                </div>
                <div class="inside">
                    <input id="file_upload" type="file" name="my_file_upload" accept=".csv">
                    <div id="dragandrophandler">Drop CSV File or<br />Click Here to upload!</div>
                    <div id="dragandrophandlerstatus">Processing!</div>
                    <div id="field_mapper_wrapper">
                        <h3>MAP FIELDS</h3>
                        <form id="field_mapper">
                            <div class="map">
                                <label for="map_id">ID - Is set for you</label>
                                <input type="text" id="map_id" name="map_id" value="" disabled />
                            </div>
                            <?php // get the user fields
                            $fields = $this->get_user_fields();
                            foreach ($fields as $field_id => $field_name) {
                                echo "<div class=\"map\"><label for=\"{$field_id}\">{$field_name}</label><select id=\"{$field_id}\" name=\"{$field_id}\" class=\"mepr_fields\"><option value=\"NULL\">Don't Update</option></select></div>";
                            }
                            ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .postbox-container {
                width: 100%;
            }

            .postbox-container .postbox {
                width: 50%;
            }

            #dragandrophandler,
            #dragandrophandlerstatus {
                display: flex;
                justify-content: center;
                align-items: center;
                text-align: center;
                border: 2px dotted #0B85A1;
                width: 100%;
                height: 200px;
                color: #92AAB0;
                font-size: 20px;
                cursor: pointer;
            }

            #dragandrophandlerstatus {
                display: none;
                border: 2px solid #008500;
                color: #008500;
            }

            #file_upload {
                display: none;
            }

            #field_mapper_wrapper {
                display: none;
            }

            #field_mapper_wrapper h3 {
                text-align: center;
            }

            #field_mapper {
                /*display: flex;
                    flex-wrap: wrap;
                    justify-content: space-between;
                    gap: 10px 0;*/
                column-count: 2;
                column-gap: 10px;
            }

            #field_mapper .map {
                display: flex;
                gap: 5px;
                justify-content: end;
                align-items: center;
                margin-bottom: 5px;
            }

            #field_mapper .map label {
                text-align: right;
            }

            #field_mapper .map input,
            #field_mapper .map select {
                width: 200px;
            }
        </style>
        <script>
            jQuery(document).ready(function($) {

                $("#dragandrophandler").on('click', function() {
                    $('#file_upload').click(); // Trigger the hidden file input
                });

                // Prevent default browser behavior for drag events
                $("#dragandrophandler").on('dragenter', function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                    $(this).css('border', '2px solid #0B85A1'); // Visual feedback
                });

                $("#dragandrophandler").on('dragover', function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                });

                // Handle the file drop event
                $("#dragandrophandler").on('drop', function(e) {
                    e.stopPropagation();
                    e.preventDefault();

                    $('#file_upload')[0].files = e.originalEvent.dataTransfer.files
                    $('#file_upload').trigger('change');
                });

                // UPLOAD THE FILE!!!
                $('#file_upload').on('change', function() {
                    $('#dragandrophandler').hide();
                    $('#dragandrophandlerstatus').css('display', 'flex');

                    if ($('#file_upload')[0].files.length > 0) {
                        var file_data = $('#file_upload')[0].files[0];

                        var formData = new FormData();
                        formData.append('file', file_data);
                        formData.append('parse', 'csv');
                        formData.append('action', 'my_file_upload');
                        formData.append('nonce', '<?= wp_create_nonce('ecr-file-upload-nonce') ?>');

                        $.ajax({
                            url: ajaxurl, // WordPress AJAX URL
                            type: 'post',
                            data: formData,
                            processData: false, // Important: Don't process the data
                            contentType: false, // Important: Don't set content type
                            success: function(response) {
                                // Handle successful upload response
                                console.log(response);

                                maybeid = []

                                keys = Object.keys(response.data[0])

                                keys.forEach(function(element, index) {
                                    if (element.toLowerCase() === 'id') {
                                        $('#map_id').val(element);
                                    } else {
                                        $('<option>', {
                                            value: element,
                                            text: element
                                        }).appendTo('.mepr_fields');
                                    }
                                });

                                $('#dragandrophandlerstatus').hide();
                                $('#field_mapper_wrapper').show();
                            },
                            error: function(xhr, status, error) {
                                $('#dragandrophandlerstatus').css('color', '#FF4444');
                                $('#dragandrophandlerstatus').css('border-color', '#FF4444');
                                $('#dragandrophandlerstatus').text('ERROR: xhr.responseText');
                            }
                        });


                    }

                });

            });

            jQuery(document).ready(function($) {
                $('#my-upload-form').submit(function(e) {
                    e.preventDefault(); // Prevent default form submission

                    var file_data = jQuery('#my-file-input').prop('files')[0];

                    var formData = new FormData();
                    formData.append('file', file_data);
                    formData.append('parse', 'csv');
                    formData.append('action', 'my_file_upload');
                    formData.append('nonce', '<?= wp_create_nonce('ecr-file-upload-nonce') ?>');

                    $.ajax({
                        url: ajaxurl, // WordPress AJAX URL
                        type: 'post',
                        data: formData,
                        processData: false, // Important: Don't process the data
                        contentType: false, // Important: Don't set content type
                        success: function(response) {
                            // Handle successful upload response
                            console.log(response);
                            $('#upload_parsed').text(response.data);
                        },
                        error: function(xhr, status, error) {
                            // Handle error
                            console.error(xhr.responseText);
                        }
                    });
                });
            });
            /* document.getElementById('uploadForm').addEventListener('submit', function(event) {
                 event.preventDefault(); // Prevent the default form submission

                 const fileInput = document.getElementById('fileInput');
                 const statusDiv = document.getElementById('status');

                 // Create a FormData object to hold the file data
                 const formData = new FormData();
                 formData.append('fileInput', fileInput.files[0]); // 'fileInput' must match the PHP script's $_FILES key

                 statusDiv.innerHTML = 'Uploading...';



                 /*
                 fetch('upload.php', {
                         method: 'POST',
                         body: formData,
                     })
                     .then(response => response.text())
                     .then(text => {
                         console.log(text); // Display the response from the server
                     })
                     .catch(error => {
                         statusDiv.innerHTML = 'Error uploading file.';
                         console.error('Error:', error);
                     });
             });*/
        </script>
<?php
        /*
            
            CSV FILE TO TRY AND PULL IN PHONE Numbers from, code needs to be udpated to reflect column number for phone

            $filePath = ECR_DIR . '/src/members-1751295111.csv'; // Replace with your CSV file path

            if (($handle = fopen($filePath, 'r')) !== FALSE) {
                $members = [];
                while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                    // $data is an array representing a row in the CSV
                    // You can access fields by index: $data[0], $data[1], etc.
                    $user_id = $data[0]; // ID
                    $phone = $data[32];
                    echo "<div>{$user_id} - {$phone}</div>";
                    update_user_meta($user_id, 'mepr_practice_phone', $phone, '');
                }
                fclose($handle);
            } else {
                echo "Error opening CSV file.";
            }*/

    }
}
