<?php

/**
 * Plugin Name: ECR Options
 * Description: Custom built plugin for Eyecare Republic website
 * Version: 1.0.0
 * Author: DJ
 * Author URI: https://alphawolfweb.com/
 * Network: true
 * Text Domain: ecroptions
 * License: GPLv2 or later
 */

namespace ECROptions;

defined('ABSPATH') || exit;
define('ECR_URL', plugins_url('', __FILE__));
define('ECR_DIR', plugin_dir_path(__FILE__));

require __DIR__ . '/vendor/autoload.php';

class Main
{
    function __construct()
    {
        // grab the updater
        //new Updater();


        // because the SalesforceConnector creates a rest endpoint, we need to allways instance it
        SalesforceConnector::getInstance();

        new FileUpload();
        new AdminPage();
        new RegistrationForm();

        // enqueue the admin javascript
        add_action('admin_enqueue_scripts', [$this, 'admin_scripts']);

        add_action('wp_ajax_ecr_options', [$this, 'handle_ecr_options_ajax']);
        add_action('wp_ajax_nopriv_ecr_options', [$this, 'handle_ecr_options_ajax']);
    }

    function admin_scripts()
    {
        wp_enqueue_style('ect-admin-style', ECR_URL . '/assets/css/admin.css', [], time());

        wp_enqueue_script('ecr-admin-script', ECR_URL . '/assets/js/admin.js', ['jquery'], time(), true);
        wp_localize_script('ecr-admin-script', 'ajaxurl', admin_url('admin-ajax.php'));
        wp_localize_script('ecr-admin-script', 'nonce', wp_create_nonce('ecr-options'));
    }

    function handle_ecr_options_ajax()
    {
        if (! check_ajax_referer('ecr-options', 'nonce', false)) {
            wp_send_json_error('Security failed.');
            wp_die();
        }

        new AJAX;

        call_user_func("\ECROptions\AJAX::{$_POST['method']}");

        wp_die();
    }

    static function get_template($name, $data)
    {
        extract($data);
        include(ECR_DIR . "/templates/{$name}.template.php");
    }
}

new Main();
